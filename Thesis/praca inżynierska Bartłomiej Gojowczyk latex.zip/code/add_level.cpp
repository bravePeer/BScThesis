Level* loadLevel0()
{
	Level* level = new Level(L"identyfikator", L"Nazwa", L"Opis", true);
	level->setPrevLevelsIds({ }); //ustawienie poprzednich poziomów

	level->setComponentsGraphicsToLoad([]()->void {
		GraphicManager& graphics = GraphicManager::GetInstance();
		graphics.addGraphicToLoad("resistor", RESISTOR_GRAPHIC_PATH);
		graphics.addGraphicToLoad("goldpin", GOLDPIN_GRAPHIC_PATH); });

	level->setGenerateComponents(([](int* componentsCount)->Component** {
		*componentsCount = 1;
		Component** components = new Component * [*componentsCount];
		//Utworzenie pozycji padów
		components[0] = new Resistor(L"Opornik", L"opis", Vector2i(2, 1), 2, pad_pos, GraphicManager::GetInstance().getComponentTexture("resistor"), Component::ComponentTypePackage::SMD, true, "id0");
		components[0]->setSimValue("100R");
		return components;
		}));

	level->setCheckBoard([](Board* board)->bool {
		map<std::string, int> componentsCount = board->getComponentsCountById();
		if (componentsCount.find("id1")->second != 1)
			return false;
		return true;
		});

	level->setCheckSimulation([](Board* board, SimulationEngine* sim)->bool {
		if (sim->getComponentValue("res0id0") > 0.1)
			return false;
		return true;
		});

	return level;
}